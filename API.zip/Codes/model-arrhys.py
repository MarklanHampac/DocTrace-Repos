from database.db_connect import create_app, init_mysql
from flask import Flask, jsonify, request
import json
import JWT

mysql = init_mysql(create_app())

# start of user SP


def login_user():
    # Retrieve JSON data from the request
    data = request.get_json()

    # Extract username, password, and email from the JSON data
    username = data.get("username")
    password = data.get("password")
    email = data.get("email")

    if not username or not password or not email:
        return jsonify({"error": "Username, password, and email are required"}), 400

    try:
        # Execute the stored procedure to get API key
        cur = mysql.connection.cursor()
        cur.execute("CALL GetApiKey(%s, %s, %s)", (username, password, email))
        result = cur.fetchone()
        cur.close()

        if result:
            if "api_key" in result:  # Check if API key is retrieved
                db_api_key = result["api_key"]

                # Generate JWT token using user_info
                user_info = {
                    "username": data["username"],
                    "password": data["password"],
                    "email": data["email"],
                }
                jwt_api_key = JWT.generateJWToken(user_info)

                # Compare the API key from database with JWT generated API key
                if jwt_api_key == db_api_key:
                    verification_message = "Key verified"
                else:
                    verification_message = "Key verification failed"

                # Create response dictionary
                response_data = {
                    "Result": "Login successful",
                    "Verification": verification_message,
                    "Database_API_Key": db_api_key,
                    "Generated_API_Key": jwt_api_key,
                }

                # Attach API key to the response
                response_data["APIKey"] = db_api_key

                # Create a JSON response
                response = jsonify(response_data)
                return response
            else:
                # API key retrieval failed
                return jsonify({"error": result["error"]}), 401
        else:
            return jsonify({"error": "Login failed"}), 401
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def update_users():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call users_update('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def search_users():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call users_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    response.headers["Custom-Header"] = JWT.register()
    return response


def load_users():
    cur = mysql.connection.cursor()
    cur.execute("call users_load()")
    result = cur.fetchall()
    cur.close()
    return result


######### END OF USER SP ###########

######## START OF STATEDEF #############


def statedef_update_users():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call statedef_update('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def statedef_search_users():
    try:
        # Retrieve JSON data from the request
        data = request.get_json()
        data_string = json.dumps(data)

        # Execute the stored procedure to search for state definitions
        cur = mysql.connection.cursor()
        cur.execute(f"CALL statedef_search('{data_string}')")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


def statedef_load_perdoc_users():
    try:
        data = request.get_json()
        data_string = json.dumps(data)

        cur = mysql.connection.cursor()
        cur.execute(f"CALL statedef_load_perdoc('{data_string}')")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions per document
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


def statedef_load_users():
    try:
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute("CALL statedef_load()")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


######################### END OF STATEDEF SP ####################################


######################### START OF NOTIFIACTION SP ####################################


def load_notification():
    try:
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute("CALL notifucations_load()")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


def update_notification():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call notification_update('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def search_notification():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call notification_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    return response


######################### END OF NOTIFIACTION SP ####################################


######################### START OF DOCUMENTSTATUS SP ####################################


def load_documenttype_status():
    try:
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute("CALL documenttype_load_status()")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


######################### END OF DOCUMENTSTATUS SP ####################################


######################### START OF DOCUMENTSHISTORY SP ####################################


def update_documenthistory():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call documenthistory_update('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def search_documenthistory():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call documenthistory_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    return response


def load_documenthistory():
    try:
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute("CALL documenthistory_load()")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


######################### END OF DOCUMENTSHISTORY SP ####################################


######################### START OF DOCUMENTSCOMMENTS SP ####################################


def update_documentcomments():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call documentcomments_update('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def search_documentcomments():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call documentcomments_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    return response


def load_documentcomments():
    try:
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute("CALL documentcomments_load()")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


######################### END OF DOCUMENTSCOMMENTS SP ####################################


######################### START OF DEPARTMENTS SP ####################################


def update_departments():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call departments_update('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def search_departments():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call departments_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    return response


def load_departments():
    try:
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute("CALL departments_load()")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


######################### END OF DEPARTMENTS SP ####################################


######################### START OF DEPARTMENTS SP ####################################


def update_accesscontrol():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call accesscontrol_update('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def search_accesscontrol():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call accesscontrol_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    return response


def load_accesscontrol():
    try:
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute("CALL accesscontrol_load()")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


######################### END OF DEPARTMENTS SP ####################################


# ======================================================================================================================================


def count_documents():
    cur = mysql.connection.cursor()
    cur.execute("call document_count()")
    result = cur.fetchall()
    cur.close()
    return result


def count_document_status():
    cur = mysql.connection.cursor()
    cur.execute("call document_status_count()")
    result = cur.fetchall()
    cur.close()
    return result


def documents_search():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call documents_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    response.headers["Custom-Header"] = JWT.register()
    return response


def documenthistory_search():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call documenthistory_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    response.headers["Custom-Header"] = JWT.register()
    return response


def documentcomments_search():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call documentcomments_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    response.headers["Custom-Header"] = JWT.register()
    return response


def documentcategories_search():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call documentcategories_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    response.headers["Custom-Header"] = JWT.register()
    return response


def document_category_mapping_search():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call document_category_mapping_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    response.headers["Custom-Header"] = JWT.register()
    return response


def count_users():
    cur = mysql.connection.cursor()
    cur.execute("call user_count()")
    result = cur.fetchall()
    cur.close()
    return result
