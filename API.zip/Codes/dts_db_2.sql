/*
 Navicat Premium Data Transfer

 Source Server         : mysql_server_localhost
 Source Server Type    : MySQL
 Source Server Version : 80300 (8.3.0)
 Source Host           : localhost:3307
 Source Schema         : dts_db_2

 Target Server Type    : MySQL
 Target Server Version : 80300 (8.3.0)
 File Encoding         : 65001

 Date: 28/05/2024 17:38:49
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for accesscontrol
-- ----------------------------
DROP TABLE IF EXISTS `accesscontrol`;
CREATE TABLE `accesscontrol`  (
  `access_id` int NOT NULL AUTO_INCREMENT,
  `documenttype_id` int NULL DEFAULT NULL,
  `position_id` int NULL DEFAULT NULL,
  `access_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`access_id`) USING BTREE,
  INDEX `DocumentID`(`documenttype_id` ASC) USING BTREE,
  INDEX `UserID`(`position_id` ASC) USING BTREE,
  CONSTRAINT `accesscontrol_ibfk_1` FOREIGN KEY (`documenttype_id`) REFERENCES `documenttypes` (`documenttype_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `accesscontrol_ibfk_2` FOREIGN KEY (`position_id`) REFERENCES `positions` (`position_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of accesscontrol
-- ----------------------------
INSERT INTO `accesscontrol` VALUES (1, 10, 1, '1');
INSERT INTO `accesscontrol` VALUES (3, 1, 2, '1');
INSERT INTO `accesscontrol` VALUES (4, 1, 3, '1');
INSERT INTO `accesscontrol` VALUES (5, 2, 4, '2');
INSERT INTO `accesscontrol` VALUES (6, 1, 5, '3');
INSERT INTO `accesscontrol` VALUES (8, 6, 2, '1');
INSERT INTO `accesscontrol` VALUES (9, 1, 2, '1');
INSERT INTO `accesscontrol` VALUES (10, 1, 3, '1');
INSERT INTO `accesscontrol` VALUES (23, 2, 7, '2');
INSERT INTO `accesscontrol` VALUES (24, 3, 3, '2');
INSERT INTO `accesscontrol` VALUES (25, 2, 3, '2');
INSERT INTO `accesscontrol` VALUES (26, 1, 7, '2');
INSERT INTO `accesscontrol` VALUES (27, 2, 7, '4');
INSERT INTO `accesscontrol` VALUES (28, 2, 4, '5');
INSERT INTO `accesscontrol` VALUES (29, 3, 4, '3');
INSERT INTO `accesscontrol` VALUES (30, 1, 2, '1');

-- ----------------------------
-- Table structure for apikey
-- ----------------------------
DROP TABLE IF EXISTS `apikey`;
CREATE TABLE `apikey`  (
  `api_id` int NOT NULL AUTO_INCREMENT,
  `account_id` int NULL DEFAULT NULL,
  `api_key` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `date_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`api_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 39 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of apikey
-- ----------------------------
INSERT INTO `apikey` VALUES (27, 3, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2luZm8iOnsicGFzc3dvcmQiOiJtYW5ueTEyNDUiLCJlbWFpbCI6Im1hbm55MTIzQGdtYWlsLmNvbSJ9fQ.6HUSxgGPAC3gwrdo6CUGHhAbGeTwxlfOcizCt-Yb1TE', '2024-04-15 09:44:53');
INSERT INTO `apikey` VALUES (37, 15, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2luZm8iOnsicGFzc3dvcmQiOiJ1c2VyMTIzIiwiZW1haWwiOiJ1c2VyMUBnbWFpbC5jb20ifX0.1oBto9Dgk-7uiMZ88CQ_rzttV4qbUiNExglfPFY625E', '2024-05-28 11:12:49');
INSERT INTO `apikey` VALUES (38, 16, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2luZm8iOnsicGFzc3dvcmQiOiJ1c2VyMTIzIiwiZW1haWwiOiJ1c2VyMkBnbWFpbC5jb20ifX0.RUibNXuiK9dW8qlRmwa6QTX-TYNnqXEwRKNNzgM4HqA', '2024-05-28 17:00:18');

-- ----------------------------
-- Table structure for departments
-- ----------------------------
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments`  (
  `department_id` int NOT NULL AUTO_INCREMENT,
  `department_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`department_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of departments
-- ----------------------------
INSERT INTO `departments` VALUES (1, 'CCS');
INSERT INTO `departments` VALUES (2, 'CCJE');
INSERT INTO `departments` VALUES (3, 'CRIM');
INSERT INTO `departments` VALUES (4, 'CAS');
INSERT INTO `departments` VALUES (5, 'CBA');
INSERT INTO `departments` VALUES (6, 'MARITIME');

-- ----------------------------
-- Table structure for documentcomments
-- ----------------------------
DROP TABLE IF EXISTS `documentcomments`;
CREATE TABLE `documentcomments`  (
  `comment_id` int NOT NULL AUTO_INCREMENT,
  `document_id` int NULL DEFAULT NULL,
  `comment_date` datetime NULL DEFAULT NULL,
  `commenter` int NULL DEFAULT NULL,
  `comment_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  PRIMARY KEY (`comment_id`) USING BTREE,
  INDEX `DocumentID`(`document_id` ASC) USING BTREE,
  INDEX `Commenter`(`commenter` ASC) USING BTREE,
  CONSTRAINT `documentcomments_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `documents` (`document_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `documentcomments_ibfk_2` FOREIGN KEY (`commenter`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of documentcomments
-- ----------------------------

-- ----------------------------
-- Table structure for documenthistory
-- ----------------------------
DROP TABLE IF EXISTS `documenthistory`;
CREATE TABLE `documenthistory`  (
  `history_id` int NOT NULL AUTO_INCREMENT,
  `document_id` int NULL DEFAULT NULL,
  `action` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `action_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `actor` int NULL DEFAULT NULL,
  `department_id` int NULL DEFAULT NULL,
  `documenttype_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`history_id`) USING BTREE,
  INDEX `DocumentID`(`document_id` ASC) USING BTREE,
  INDEX `Actor`(`actor` ASC) USING BTREE,
  INDEX `documenttyp_id`(`documenttype_id` ASC) USING BTREE,
  INDEX `department_id`(`department_id` ASC) USING BTREE,
  CONSTRAINT `documenthistory_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `documents` (`document_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `documenthistory_ibfk_2` FOREIGN KEY (`actor`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `documenthistory_ibfk_3` FOREIGN KEY (`documenttype_id`) REFERENCES `documents` (`documenttype_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `documenthistory_ibfk_4` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 178 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of documenthistory
-- ----------------------------

-- ----------------------------
-- Table structure for documents
-- ----------------------------
DROP TABLE IF EXISTS `documents`;
CREATE TABLE `documents`  (
  `document_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NULL DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `author` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int NULL DEFAULT NULL,
  `documenttype_id` int NULL DEFAULT NULL,
  `department_id` int NULL DEFAULT NULL,
  `file_path` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `isDone` int NULL DEFAULT 0,
  `doc_status` int NULL DEFAULT 0,
  PRIMARY KEY (`document_id`) USING BTREE,
  INDEX `user_id`(`user_id` ASC) USING BTREE,
  INDEX `documenttype_id`(`documenttype_id` ASC) USING BTREE,
  INDEX `deparment_id`(`department_id` ASC) USING BTREE,
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`documenttype_id`) REFERENCES `documenttypes` (`documenttype_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `documents_ibfk_3` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 71 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of documents
-- ----------------------------

-- ----------------------------
-- Table structure for documenttypes
-- ----------------------------
DROP TABLE IF EXISTS `documenttypes`;
CREATE TABLE `documenttypes`  (
  `documenttype_id` int NOT NULL AUTO_INCREMENT,
  `documenttype_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`documenttype_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of documenttypes
-- ----------------------------
INSERT INTO `documenttypes` VALUES (1, 'Syllabus');
INSERT INTO `documenttypes` VALUES (2, 'Exam Schedule');
INSERT INTO `documenttypes` VALUES (3, 'Assignment Guidelines');
INSERT INTO `documenttypes` VALUES (4, 'Course Outline');
INSERT INTO `documenttypes` VALUES (5, 'Student Handbook');
INSERT INTO `documenttypes` VALUES (6, 'Academic Calendar');
INSERT INTO `documenttypes` VALUES (7, 'Grading Rubric');
INSERT INTO `documenttypes` VALUES (8, 'Registration Form');
INSERT INTO `documenttypes` VALUES (9, 'Library Rules');
INSERT INTO `documenttypes` VALUES (10, 'Code of Conduct');
INSERT INTO `documenttypes` VALUES (11, 'Educational Resources');
INSERT INTO `documenttypes` VALUES (12, 'Administrative Documents');
INSERT INTO `documenttypes` VALUES (13, 'Student Affairs');
INSERT INTO `documenttypes` VALUES (14, 'Academic Policies');
INSERT INTO `documenttypes` VALUES (15, 'Curriculum Materials');
INSERT INTO `documenttypes` VALUES (16, 'Regulatory Documents');
INSERT INTO `documenttypes` VALUES (17, 'Financial Information');
INSERT INTO `documenttypes` VALUES (18, 'Campus Facilities');
INSERT INTO `documenttypes` VALUES (19, 'Health and Safety Guidelines');
INSERT INTO `documenttypes` VALUES (20, 'Student Activities');
INSERT INTO `documenttypes` VALUES (22, 'def');
INSERT INTO `documenttypes` VALUES (23, 'fed');

-- ----------------------------
-- Table structure for notification
-- ----------------------------
DROP TABLE IF EXISTS `notification`;
CREATE TABLE `notification`  (
  `notification_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NULL DEFAULT NULL,
  `notification_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `notification_date` date NULL DEFAULT NULL,
  `is_read` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`notification_id`) USING BTREE,
  INDEX `UserID`(`user_id` ASC) USING BTREE,
  CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of notification
-- ----------------------------

-- ----------------------------
-- Table structure for positions
-- ----------------------------
DROP TABLE IF EXISTS `positions`;
CREATE TABLE `positions`  (
  `position_id` int NOT NULL AUTO_INCREMENT,
  `position_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`position_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of positions
-- ----------------------------
INSERT INTO `positions` VALUES (1, 'Department Head');
INSERT INTO `positions` VALUES (2, 'Academic Coordinator');
INSERT INTO `positions` VALUES (3, 'Course Instructor');
INSERT INTO `positions` VALUES (4, 'Dean of Students');
INSERT INTO `positions` VALUES (5, 'Registrar');
INSERT INTO `positions` VALUES (6, 'Librarian');
INSERT INTO `positions` VALUES (7, 'Student Affairs Director');
INSERT INTO `positions` VALUES (8, 'Academic Dean');
INSERT INTO `positions` VALUES (9, 'Curriculum Coordinator');
INSERT INTO `positions` VALUES (10, 'Legal Counsel');
INSERT INTO `positions` VALUES (11, 'Chief Financial Officer');
INSERT INTO `positions` VALUES (12, 'Facilities Manager');
INSERT INTO `positions` VALUES (13, 'Health and Safety Officer');
INSERT INTO `positions` VALUES (14, 'Student Activities Coordinator');
INSERT INTO `positions` VALUES (15, 'Administrative Officer');
INSERT INTO `positions` VALUES (16, 'Budget Committee');
INSERT INTO `positions` VALUES (17, 'Safety Officer');
INSERT INTO `positions` VALUES (18, 'Director of Student Affairs');
INSERT INTO `positions` VALUES (19, 'Course Coordinator');
INSERT INTO `positions` VALUES (20, 'Chief Executive Officer');
INSERT INTO `positions` VALUES (21, 'Compliance Officer');

-- ----------------------------
-- Table structure for state_def
-- ----------------------------
DROP TABLE IF EXISTS `state_def`;
CREATE TABLE `state_def`  (
  `state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `state_desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `documenttype_id` int NULL DEFAULT NULL,
  INDEX `documenttype_id`(`documenttype_id` ASC) USING BTREE,
  CONSTRAINT `state_def_ibfk_1` FOREIGN KEY (`documenttype_id`) REFERENCES `documenttypes` (`documenttype_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of state_def
-- ----------------------------
INSERT INTO `state_def` VALUES ('1-2-3-4', 'submitted-review-approval-approved', 1);
INSERT INTO `state_def` VALUES ('1-2-3-4-5', 'submitted-review-approval-approved-ok', 2);
INSERT INTO `state_def` VALUES ('1-2-3-4', 'submitted-review-approval-approved', 3);
INSERT INTO `state_def` VALUES ('1-2-3-4', 'submitted-review-approval-approved ', 22);
INSERT INTO `state_def` VALUES ('1-2-3-4', 'submitted-review-approval-approved ', 23);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `position_id` int NOT NULL,
  `department_id` int NULL DEFAULT NULL,
  `user_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`) USING BTREE,
  INDEX `department_id`(`department_id` ASC) USING BTREE,
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (3, 'Manny', 'manny1245', 'Manny Pacquiao', 'manny123@gmail.com', 1, 1, 'ADMIN');
INSERT INTO `users` VALUES (15, 'user1', 'user123', 'User 1', 'user1@gmail.com', 2, 1, 'USER');
INSERT INTO `users` VALUES (16, 'user2', 'user123', 'user2', 'user2@gmail.com', 1, 3, 'USER');

-- ----------------------------
-- Procedure structure for accesscontrol_load
-- ----------------------------
DROP PROCEDURE IF EXISTS `accesscontrol_load`;
delimiter ;;
CREATE PROCEDURE `accesscontrol_load`()
BEGIN
	SELECT users.full_name, positions.position_name, documenttypes.documenttype_name, access_type 
	FROM accesscontrol
	INNER JOIN positions ON accesscontrol.position_id = positions.position_id
	INNER JOIN users ON accesscontrol.position_id = users.position_id
	INNER JOIN documenttypes ON accesscontrol.documenttype_id = documenttypes.documenttype_id;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for accesscontrol_search
-- ----------------------------
DROP PROCEDURE IF EXISTS `accesscontrol_search`;
delimiter ;;
CREATE PROCEDURE `accesscontrol_search`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE result_status VARCHAR(100);
    DECLARE _SearchKey VARCHAR(255);
    
    SET _SearchKey = getvalue(JsonData,'$.SearchKey');
    SET result_status = CONCAT('No Rcord with search key: ', _SearchKey);

    IF EXISTS (SELECT * FROM accesscontrol WHERE access_id LIKE CONCAT('%', _SearchKey, '%')) THEN
        BEGIN
            SELECT * FROM accesscontrol WHERE access_id LIKE CONCAT('%', _SearchKey, '%') LIMIT 1;
        END;
    ELSE
        BEGIN
            SELECT result_status;
        END;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for accesscontrol_update
-- ----------------------------
DROP PROCEDURE IF EXISTS `accesscontrol_update`;
delimiter ;;
CREATE PROCEDURE `accesscontrol_update`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE _statusmsg VARCHAR(255) DEFAULT 'ERROR OCCURED';
    DECLARE _statusno SMALLINT DEFAULT 0;

    DECLARE _access_id VARCHAR(255);
    DECLARE _documenttype_id INT;
    DECLARE _position_id VARCHAR(255);
    DECLARE _access_type VARCHAR(10);

    SET _access_id = getvalue(JsonData, '$.access_id');
    SET _documenttype_id = getvalue(JsonData, '$.documenttype_id');
    SET _position_id = getvalue(JsonData, '$.position_id');
    SET _access_type = getvalue(JsonData, '$.access_type');

    IF EXISTS (SELECT * FROM accesscontrol WHERE access_id = _access_id) THEN
        BEGIN
            UPDATE accesscontrol 
            SET document_id = _document_id,
                position_id = _position_id,
                access_type = _access_type
            WHERE access_id = _access_id;

            SET _statusmsg = "RECORD UPDATED";
            SET _statusno = 1;
            SELECT _statusmsg AS result, _statusno AS statuscode;
        END;
    ELSE
        BEGIN
            IF _documenttype_id IS NOT NULL THEN
                INSERT INTO accesscontrol (
                    access_id,
                    documenttype_id,
                    position_id,
                    access_type
                ) VALUES (
                    _access_id,
                    _documenttype_id,
                    _position_id,
                    _access_type
                );

                SET _statusmsg = "RECORD INSERTED";
                SET _statusno = 1;
                SELECT _statusmsg AS result, _statusno AS statuscode;
            ELSE    
                SELECT _statusmsg AS result, _statusno AS statuscode;
            END IF;
        END;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for apikey_update
-- ----------------------------
DROP PROCEDURE IF EXISTS `apikey_update`;
delimiter ;;
CREATE PROCEDURE `apikey_update`(IN `JsonData` LONGTEXT)
BEGIN
		DECLARE _statusmsg LONGTEXT DEFAULT 'Error Occured';
    DECLARE _statusno SMALLINT DEFAULT 0;

    DECLARE _account_id INT;
    DECLARE _api_key LONGTEXT;
   

    SET _account_id = getvalue(JsonData, '$.account_id');
    SET _api_key = getvalue(JsonData, '$.api_key');
    

    IF EXISTS (SELECT * FROM apikey WHERE account_id = _account_id) THEN
        BEGIN
            UPDATE apikey 
            SET api_key = _api_key
                
            WHERE account_id = _account_id;

            SET _statusmsg = "RECORD UPDATED";
            SET _statusno = 1;
            SELECT _statusmsg AS result, _statusno AS statuscode;
        END;
    ELSE
        BEGIN
            IF _account_id IS NOT NULL THEN
                INSERT INTO apikey (account_id, api_key)
                VALUES (_account_id, _api_key);

                SET _statusmsg = "RECORD INSERTED";
                SET _statusno = 1;
                SELECT _statusmsg AS result, _statusno AS statuscode;
            ELSE    
                SELECT _statusmsg AS result, _statusno AS statuscode;
            END IF;
        END;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for departments_load
-- ----------------------------
DROP PROCEDURE IF EXISTS `departments_load`;
delimiter ;;
CREATE PROCEDURE `departments_load`()
BEGIN
	SELECT * FROM departments;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for departments_search
-- ----------------------------
DROP PROCEDURE IF EXISTS `departments_search`;
delimiter ;;
CREATE PROCEDURE `departments_search`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE Result_Status VARCHAR(100);
    DECLARE _SearchKey VARCHAR(255);
    
    SET _SearchKey = getvalue(JsonData,'$.SearchKey');
    SET Result_Status = CONCAT('No Record exist with search key: ', _SearchKey);

    IF EXISTS (SELECT * FROM departments WHERE department_id LIKE CONCAT('%', _SearchKey, '%') OR department_name LIKE CONCAT('%', _SearchKey, '%') ) THEN
        BEGIN
            SELECT * FROM departments WHERE department_id LIKE CONCAT('%', _SearchKey, '%') OR department_name LIKE CONCAT('%', _SearchKey, '%') LIMIT 1;
        END;
    ELSE
        BEGIN
            SELECT Result_Status;
        END;
    END IF;
    
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for departments_update
-- ----------------------------
DROP PROCEDURE IF EXISTS `departments_update`;
delimiter ;;
CREATE PROCEDURE `departments_update`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE _statusmsg LONGTEXT DEFAULT 'Error Occured';
    DECLARE _statusno SMALLINT DEFAULT 0;

    DECLARE _department_id VARCHAR(255);
    DECLARE _department_name VARCHAR(255);

    SET _department_id = getvalue(JsonData, '$.department_id');
    SET _department_name = getvalue(JsonData, '$.department_name');

    IF EXISTS (SELECT * FROM Departments WHERE department_id = _department_id) THEN
        BEGIN
            UPDATE departments 
            SET department_name = _department_name
            WHERE department_id = _department_id;

            SET _statusmsg = "RECORD UPDATED";
            SET _statusno = 1;
            SELECT _statusmsg AS result, _statusno AS statuscode;
        END;
    ELSE
        BEGIN
            IF _department_id IS NOT NULL THEN
                INSERT INTO departments (
                    department_id,
                    department_name
                ) VALUES (
                    _department_id,
                    _department_name
                );

                SET _statusmsg = "RECORD INSERTED";
                SET _statusno = 1;
                SELECT _statusmsg AS result, _statusno AS statuscode;
            ELSE    
                SELECT _statusmsg AS result, _statusno AS statuscode;
            END IF;
        END;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documentcomments_load
-- ----------------------------
DROP PROCEDURE IF EXISTS `documentcomments_load`;
delimiter ;;
CREATE PROCEDURE `documentcomments_load`()
BEGIN
	SELECT * FROM documentcomments;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documentcomments_search
-- ----------------------------
DROP PROCEDURE IF EXISTS `documentcomments_search`;
delimiter ;;
CREATE PROCEDURE `documentcomments_search`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE Result_Status VARCHAR(100);
    DECLARE _SearchKey VARCHAR(255);
    
    SET _SearchKey = getvalue(JsonData,'$.SearchKey');
    SET Result_Status = CONCAT('No Records exist with search key: ', _SearchKey);

    IF EXISTS (SELECT * FROM documentcomments WHERE comment_id LIKE CONCAT('%', _SearchKey, '%')) THEN
        BEGIN
            SELECT * FROM documentcomments WHERE comment_id LIKE CONCAT('%', _SearchKey, '%') LIMIT 1 ;
        END;
    ELSE
        BEGIN
            SELECT Result_Status;
        END;
    END IF;
    
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documentcomments_update
-- ----------------------------
DROP PROCEDURE IF EXISTS `documentcomments_update`;
delimiter ;;
CREATE PROCEDURE `documentcomments_update`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE _statusmsg LONGTEXT DEFAULT '';
    DECLARE _statusno SMALLINT DEFAULT 0;

    DECLARE _comment_id VARCHAR(255);
    DECLARE _document_id VARCHAR(255);
    DECLARE _comment_date VARCHAR(255);
    DECLARE _commenter VARCHAR(255);
    DECLARE _comment_text VARCHAR(255);

    SET _comment_id = getvalue(JsonData, '$.comment_id');
    SET _document_id = getvalue(JsonData, '$.document_id');
    SET _comment_date = getvalue(JsonData, '$.comment_date');
    SET _commenter = getvalue(JsonData, '$.commenter');
    SET _comment_text = getvalue(JsonData, '$.comment_text');

    IF EXISTS (SELECT * FROM documentcomments WHERE comment_id = _comment_id) THEN
        BEGIN
            UPDATE documentcomments 
            SET document_id = _document_id,
                comment_date = _comment_date,
                commenter = _commenter,
                comment_text = _comment_text
            WHERE comment_id = _comment_id;

            SET _statusmsg = "RECORD UPDATED";
            SET _statusno = 1;
            SELECT _statusmsg AS result, _statusno AS statuscode;
        END;
    ELSE
        BEGIN
            IF _comment_id IS NOT NULL THEN
                INSERT INTO documentcomments (
                    comment_id,
                    document_id,
                    comment_date,
                    commenter,
                    comment_text
                ) VALUES (
                    _comment_id,
                    _document_id,
                    _comment_date,
                    _commenter,
                    _comment_text
                );

                SET _statusmsg = "RECORD INSERTED";
                SET _statusno = 1;
                SELECT _statusmsg AS result, _statusno AS statuscode;
            ELSE    
                SELECT _statusmsg AS result, _statusno AS statuscode;
            END IF;
        END;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documenthistory_load
-- ----------------------------
DROP PROCEDURE IF EXISTS `documenthistory_load`;
delimiter ;;
CREATE PROCEDURE `documenthistory_load`()
BEGIN
	Select * FROM Documenthistory;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documenthistory_search
-- ----------------------------
DROP PROCEDURE IF EXISTS `documenthistory_search`;
delimiter ;;
CREATE PROCEDURE `documenthistory_search`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE Result_Status VARCHAR(100);
    DECLARE _SearchKey VARCHAR(255);
    
    SET _SearchKey = getvalue(JsonData, '$.SearchKey');
    SET Result_Status = CONCAT('No history records exist with search key: ', _SearchKey);

    IF EXISTS (SELECT * FROM documenthistory WHERE history_id LIKE CONCAT('%', _SearchKey, '%') OR  document_id LIKE CONCAT('%', _SearchKey, '%')) THEN
        BEGIN
            SELECT * FROM documenthistory WHERE history_id LIKE CONCAT('%', _SearchKey, '%') OR  document_id LIKE CONCAT('%', _SearchKey, '%');
        END;
    ELSE
        BEGIN
            SELECT Result_Status;
        END;
    END IF;
    
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documenthistory_update
-- ----------------------------
DROP PROCEDURE IF EXISTS `documenthistory_update`;
delimiter ;;
CREATE PROCEDURE `documenthistory_update`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE _statusmsg LONGTEXT DEFAULT '';
    DECLARE _statusno SMALLINT DEFAULT 0;

    DECLARE _history_id varchar(50);
    DECLARE _document_id VARCHAR(50);
    DECLARE _action VARCHAR(50);
    DECLARE _action_date VARCHAR(50);
    DECLARE _actor VARCHAR(50);
    DECLARE _comments VARCHAR(50);

    SET _history_id = getvalue(JsonData, '$.history_id');
    SET _document_id = getvalue(JsonData, '$.document_id');
    SET _action = getvalue(JsonData, '$.action');
    SET _action_date = getvalue(JsonData, '$.action_date');
    SET _actor = getvalue(JsonData, '$.actor');
    SET _comments = getvalue(JsonData, '$.comments');

    IF EXISTS (SELECT * FROM documenthistory WHERE history_id = _history_id) THEN
        BEGIN
            UPDATE history 
            SET document_id = _document_id,
                action = _action,
                action_date = _action_date,
                actor = _actor,
                comments = _comments
            WHERE history_id = _history_id;

            SET _statusmsg = "RECORD UPDATED";
            SET _statusno = 1;
            SELECT _statusmsg AS result, _statusno AS statuscode;
        END;
    ELSE
        BEGIN
            IF _history_id IS NOT NULL THEN
                INSERT INTO documenthistory (
                    document_id, action, action_date, actor, comments
                ) VALUES (
                    _document_id, _action, _action_date, _actor,  _comments
                );

                SET _statusmsg = "RECORD INSERTED";
                SET _statusno = 1;
                SELECT _statusmsg AS result, _statusno AS statuscode;
            ELSE    
                SELECT _statusmsg AS result, _statusno AS statuscode;
            END IF;
        END;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documents_load
-- ----------------------------
DROP PROCEDURE IF EXISTS `documents_load`;
delimiter ;;
CREATE PROCEDURE `documents_load`(IN JsonData LONGTEXT)
BEGIN
		DECLARE _statusmsg VARCHAR(255) DEFAULT 'NO RECORD';
    DECLARE _statusno SMALLINT DEFAULT 0;

    DECLARE _user_id INT;
    DECLARE _user_type VARCHAR(100);

    
		SET _user_id = getvalue(JsonData, '$.user_id');
		SET _user_type = UPPER(getvalue(JsonData, '$.user_type'));

		
	IF EXISTS(SELECT * FROM documents WHERE user_id = _user_id ) AND _user_type  = "USER" THEN
	
			SELECT documents.document_id, documents.title, documents.description, documents.author, documents.creation_date,
																		documents.last_modified_date, documents.`status`, documenttypes.documenttype_name, 
																		documenttypes.documenttype_id, documents.file_path, documents.isDone, 
																		state_def.state, state_def.state_desc, documents.doc_status
			FROM documents
			INNER JOIN state_def ON documents.documenttype_id = state_def.documenttype_id
			INNER JOIN documenttypes ON documents.documenttype_id = documenttypes.documenttype_id
			WHERE user_id = _user_id;
			
	ELSE
	
      SELECT documents.document_id, documents.title, documents.description, documents.author, documents.creation_date,
																		documents.last_modified_date, documents.`status`, documenttypes.documenttype_name, documents.file_path,
																		documents.isDone, state_def.state, state_def.state_desc, documents.doc_status
			FROM documents
			INNER JOIN state_def ON documents.documenttype_id = state_def.documenttype_id
			INNER JOIN documenttypes ON documents.documenttype_id = documenttypes.documenttype_id;
			
	END IF;
	
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documents_load_perposition
-- ----------------------------
DROP PROCEDURE IF EXISTS `documents_load_perposition`;
delimiter ;;
CREATE PROCEDURE `documents_load_perposition`(IN JsonData LONGTEXT)
BEGIN
    DECLARE _statusmsg VARCHAR(255) DEFAULT 'NO RECORD';
    DECLARE _statusno SMALLINT DEFAULT 0;
		
		-- Retrieve all documenttype_id values for the given position_id
    DECLARE _position_id INT;
    DECLARE _type VARCHAR(100);

    SET _position_id = getvalue(JsonData, '$.position_id');
    SET _type = UPPER(getvalue(JsonData, '$.type'));


    SET @_documenttype_ids = (SELECT GROUP_CONCAT(DISTINCT documenttype_id) FROM accesscontrol WHERE position_id = _position_id);
		SET @_access_type = (SELECT GROUP_CONCAT(DISTINCT access_type) FROM accesscontrol WHERE position_id = _position_id);
		SET @_user_id = (SELECT GROUP_CONCAT(DISTINCT user_id) FROM users WHERE position_id = _position_id);


		IF _type = "INCOMING" THEN
			IF @_documenttype_ids IS NOT NULL THEN
					
					-- If documenttype_ids are found, retrieve all documents with the specified documenttype_ids
					SET @query = CONCAT('SELECT documents.document_id, documents.title, documents.description, documents.author, documents.creation_date,
																			documents.last_modified_date, documents.`status`, documenttypes.documenttype_name, documents.file_path,
																			documents.isDone, state_def.state, state_def.state_desc, documents.doc_status
																FROM documents 
																INNER JOIN state_def ON documents.documenttype_id = state_def.documenttype_id
																INNER JOIN documenttypes ON documents.documenttype_id = documenttypes.documenttype_id
																WHERE `status` IN (', @_access_type,') AND doc_status = 0 AND documents.user_id = ',@_user_id);
					PREPARE stmt FROM @query;
					EXECUTE stmt;
					DEALLOCATE PREPARE stmt;
					
					SET _statusmsg = "RECORD FOUND";
					SET _statusno = 1;
					SELECT _statusmsg AS result, _statusno AS statuscode;
			ELSE
					-- Handle the case when _documenttype_ids is not found
					SELECT _statusmsg AS result, _statusno AS statuscode;
			END IF;
			
		ELSEIF _type = "PENDING" THEN
		
			IF @_documenttype_ids IS NOT NULL THEN
					
					-- If documenttype_ids are found, retrieve all documents with the specified documenttype_ids
					SET @query = CONCAT('SELECT documents.document_id, documents.title, documents.description, documents.author, documents.creation_date,
																			documents.last_modified_date, documents.`status`, documenttypes.documenttype_name, documents.file_path,
																			documents.isDone, state_def.state, state_def.state_desc, documents.doc_status
																FROM documents 
																INNER JOIN state_def ON documents.documenttype_id = state_def.documenttype_id
																INNER JOIN documenttypes ON documents.documenttype_id = documenttypes.documenttype_id
																WHERE `status` IN (', @_access_type,') AND doc_status = 1 AND documents.user_id = ',@_user_id);
					PREPARE stmt FROM @query;
					EXECUTE stmt;
					DEALLOCATE PREPARE stmt;
					
					SET _statusmsg = "RECORD FOUND";
					SET _statusno = 1;
					SELECT _statusmsg AS result, _statusno AS statuscode;
			ELSE
					-- Handle the case when _documenttype_ids is not found
					SELECT _statusmsg AS result, _statusno AS statuscode;
			END IF;
			
		ELSE
			-- Handle the case when _documenttype_ids is not found
					SELECT _statusmsg AS result, _statusno AS statuscode;
		END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documents_search
-- ----------------------------
DROP PROCEDURE IF EXISTS `documents_search`;
delimiter ;;
CREATE PROCEDURE `documents_search`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE Result_Status VARCHAR(100);
    DECLARE _SearchKey VARCHAR(255);
    
    SET _SearchKey = getvalue(JsonData, '$.SearchKey');
    SET Result_Status = CONCAT('No documents exist with search key: ', _SearchKey);

    IF EXISTS (SELECT * FROM documents WHERE document_id LIKE CONCAT('%', _SearchKey, '%') OR title LIKE CONCAT('%', _SearchKey, '%')) THEN
        BEGIN
            SELECT * FROM documents WHERE document_id LIKE CONCAT('%', _SearchKey, '%') OR title LIKE CONCAT('%', _SearchKey, '%') LIMIT 1;
        END;
    ELSE
        BEGIN
            SELECT Result_Status;
        END;
    END IF;
    
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documents_update
-- ----------------------------
DROP PROCEDURE IF EXISTS `documents_update`;
delimiter ;;
CREATE PROCEDURE `documents_update`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE _statusmsg LONGTEXT DEFAULT 'ERROR OCCURED';
    DECLARE _statusno SMALLINT DEFAULT 0;

    DECLARE _document_id INT;
		DECLARE _user_id INT;
    DECLARE _title VARCHAR(255);
    DECLARE _description TEXT;
		DECLARE _department_id INT;
    DECLARE _author VARCHAR(255);
    DECLARE _documenttype_id INT;
    DECLARE _last_modified_date DATETIME;
    DECLARE _status INT;
		DECLARE _file_sftp_path LONGTEXT;
  

    SET _document_id = getvalue(JsonData, '$.document_id');
		SET _user_id = getvalue(JsonData, '$.user_id');
    SET _title = getvalue(JsonData, '$.title');
    SET _description = getvalue(JsonData, '$.description');
		SET _department_id = getvalue(JsonData, '$.department_id');
    SET _author = getvalue(JsonData, '$.author');
    SET _documenttype_id = getvalue(JsonData, '$.documenttype_id');
    SET _status = getvalue(JsonData, '$.status');
		SET _file_sftp_path = getvalue(JsonData, '$.file_path');
 

    IF _user_id IS NOT NULL THEN
        BEGIN
            IF EXISTS (SELECT * FROM documents WHERE document_id = _document_id) THEN
                BEGIN
                    UPDATE documents 
                    SET user_id = _user_id,
												title = _title,
                        description = _description,
												department_id = _department_id,
                        author = _author,
                        `status` = _status,
												documenttype_id = _documenttype_id,
												file_path = _file_sftp_path
												
										
                    WHERE document_id = _document_id;
										
										SET _document_id := LAST_INSERT_ID();
												
											IF EXISTS(SELECT * FROM documents WHERE document_id = _document_id) THEN
													BEGIN											
														INSERT INTO documenthistory (document_id, action, actor, documenttype_id)
														VALUES (_document_id, 'UPDATE', _user_id, _documenttype_id);
													END;
											END IF;

										SET _statusmsg = "RECORD UPDATED";
										SET _statusno = 1;
										SELECT _statusmsg AS result, _statusno AS statuscode;
                END;
            ELSE
                BEGIN
                    IF _user_id IS NOT NULL THEN
										
                        INSERT INTO documents (
                            user_id, title, description, department_id, author, `status`, documenttype_id, file_path
                        ) VALUES (
                            _user_id, _title, _description, _department_id, _author, _status, _documenttype_id, _file_sftp_path
                        );
												
												
												SET _document_id := LAST_INSERT_ID();
												
												IF EXISTS(SELECT * FROM documents WHERE document_id = _document_id) THEN
													BEGIN											
														INSERT INTO documenthistory (document_id, action, actor, department_id, documenttype_id)
														VALUES (_document_id, 'CREATE', _user_id, _department_id, _documenttype_id);
													END;
												END IF;
												
												SET _statusmsg = "RECORD INSERTED";
												SET _statusno = 1;
												SELECT _statusmsg AS result, _statusno AS statuscode;
                    END IF;
                END;
            END IF;
        END;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documents_update_docstatus
-- ----------------------------
DROP PROCEDURE IF EXISTS `documents_update_docstatus`;
delimiter ;;
CREATE PROCEDURE `documents_update_docstatus`(IN `JsonData` LONGTEXT)
BEGIN
		DECLARE _statusmsg LONGTEXT DEFAULT 'ERROR OCCURED';
    DECLARE _statusno SMALLINT DEFAULT 0;

    DECLARE _document_id INT;
		DECLARE _user_id INT;
    DECLARE _status VARCHAR(20); -- From frontend difined values (approve, edit, reject)
		DECLARE _documenttype_id INT;
		DECLARE _department_id INT;
  

    SET _document_id = getvalue(JsonData, '$.document_id');
		SET _user_id = getvalue(JsonData, '$.user_id');
    SET _status = getvalue(JsonData, '$.status');
		SET _documenttype_id = (SELECT documenttype_id FROM documents WHERE document_id = _document_id);
		SET _department_id = (SELECT department_id FROM documents WHERE document_id = _document_id);
	
    IF _user_id IS NOT NULL THEN
        BEGIN

            IF EXISTS (SELECT * FROM documents WHERE document_id = _document_id) AND _status = "receive" THEN
                BEGIN
                    UPDATE documents 
                    SET doc_status = 1
                    WHERE document_id = _document_id;
										-- update history
										INSERT INTO documenthistory (document_id, action, actor, documenttype_id, department_id)
										VALUES (_document_id, 'RECEIVED', _user_id, _documenttype_id, _department_id);

										SET _statusmsg = "RECORD UPDATED";
										SET _statusno = 1;
										SELECT _statusmsg AS result, _statusno AS statuscode;
                END;
            ELSEIF _status = "return" THEN
                IF (SELECT 1 FROM documents WHERE document_id = _document_id)  THEN 
									UPDATE documents 
											SET doc_status = 2
											WHERE document_id = _document_id;
											-- update history
											INSERT INTO documenthistory (document_id, action, actor, documenttype_id, department_id)
											VALUES (_document_id, 'RETURN', _user_id, _documenttype_id, _department_id);

											SET _statusmsg = "RECORD UPDATED";
											SET _statusno = 1;
											SELECT _statusmsg AS result, _statusno AS statuscode;
											
									ELSE 
											SELECT _statusmsg AS result, _statusno AS statuscode;
									END IF;
            END IF;
        END;
				
    END IF;

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documents_update_state
-- ----------------------------
DROP PROCEDURE IF EXISTS `documents_update_state`;
delimiter ;;
CREATE PROCEDURE `documents_update_state`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE _statusmsg LONGTEXT DEFAULT 'ERROR OCCURED';
    DECLARE _statusno SMALLINT DEFAULT 0;

    DECLARE _document_id INT;
		DECLARE _user_id INT;
    DECLARE _status VARCHAR(20); -- From frontend difined values (approve, edit, reject)
		DECLARE _documenttype_id INT;
		DECLARE _department_id INT;
  

    SET _document_id = getvalue(JsonData, '$.document_id');
		SET _user_id = getvalue(JsonData, '$.user_id');
    SET _status = getvalue(JsonData, '$.status');
		SET _documenttype_id = (SELECT documenttype_id FROM documents WHERE document_id = _document_id);
		SET _department_id = (SELECT department_id FROM documents WHERE document_id = _document_id);
	
    IF _user_id IS NOT NULL THEN
        BEGIN

            IF EXISTS (SELECT * FROM documents WHERE document_id = _document_id) AND _status = "approve" THEN
                BEGIN
                    UPDATE documents 
                    SET `status` = `status` + 1
                    WHERE document_id = _document_id;
										-- update history
										INSERT INTO documenthistory (document_id, action, actor, documenttype_id, department_id)
										VALUES (_document_id, 'APPROVED', _user_id, _documenttype_id, _department_id);

										SET _statusmsg = "RECORD UPDATED";
										SET _statusno = 1;
										SELECT _statusmsg AS result, _statusno AS statuscode;
                END;
            ELSEIF _status = "edit" THEN
                IF (SELECT `status` FROM documents WHERE document_id = _document_id) > 1 THEN 
									UPDATE documents 
											SET `status` = `status` - 1
											WHERE document_id = _document_id;
											-- update history
											INSERT INTO documenthistory (document_id, action, actor, documenttype_id, department_id)
											VALUES (_document_id, 'EDIT', _user_id, _documenttype_id, _department_id);

											SET _statusmsg = "RECORD UPDATED";
											SET _statusno = 1;
											SELECT _statusmsg AS result, _statusno AS statuscode;
											
									ELSE 
											SELECT _statusmsg AS result, _statusno AS statuscode;
									END IF;
									
						ELSEIF _status = "reject" THEN 
						
								UPDATE documents 
                    SET `status` = 0
                    WHERE document_id = _document_id;
										-- update history
										INSERT INTO documenthistory (document_id, action, actor, documenttype_id, department_id)
										VALUES (_document_id, 'REJECTED', _user_id, _documenttype_id, _department_id);
										
										SET _statusmsg = "RECORD UPDATED";
										SET _statusno = 1;
										SELECT _statusmsg AS result, _statusno AS statuscode;

            END IF;
        END;
    END IF;
-- 		SELECT _statusmsg AS result, _statusno AS statuscode;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documenttype_load
-- ----------------------------
DROP PROCEDURE IF EXISTS `documenttype_load`;
delimiter ;;
CREATE PROCEDURE `documenttype_load`()
BEGIN
	SELECT * FROM documenttypes;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documenttype_load_status
-- ----------------------------
DROP PROCEDURE IF EXISTS `documenttype_load_status`;
delimiter ;;
CREATE PROCEDURE `documenttype_load_status`(IN `JsonData` LONGTEXT)
BEGIN

	DECLARE _documenttype_id INT;
	DECLARE _status INT;
	
	SET _documenttype_id = getvalue(JsonData, '$.documenttype_id');
	SET _status = getvalue(JsonData, '$.status');

	IF EXISTS (SELECT * FROM documents WHERE documenttype_id = _documenttype_id) THEN 
		
		SELECT state FROM state_def WHERE documenttype_id = _documenttype_id;
		
	END IF;
	
-- 	not finished
	
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for documenttype_update
-- ----------------------------
DROP PROCEDURE IF EXISTS `documenttype_update`;
delimiter ;;
CREATE PROCEDURE `documenttype_update`(IN JsonData LONGTEXT)
BEGIN
	 DECLARE _statusmsg LONGTEXT DEFAULT 'ERROR OCCURED';
    DECLARE _statusno SMALLINT DEFAULT 0;
		
    DECLARE _documenttype_id INT;
    DECLARE _documenttype_name VARCHAR(255);
		
    SET _documenttype_id = getvalue(JsonData, '$.documenttype_id');
		SET _documenttype_name = getvalue(JsonData, '$.documenttype_name');
		
		
    IF EXISTS (SELECT * FROM documenttypes WHERE documenttype_id = _documenttype_id) THEN
        BEGIN
            UPDATE documenttypes 
            SET documenttype_name = _documenttypename
            WHERE documenttype_id = _documenttype_id;
							
							SET _statusmsg = "RECORD UPDATED";
              SET _statusno = 1;
							SELECT _statusmsg AS result, _statusno AS statuscode;
        END;
    ELSE
        BEGIN
	
              INSERT INTO documenttypes (documenttype_name)
              VALUES (_documenttype_name);

              
							SET _statusmsg = "RECORD INSERTED";
              SET _statusno = 1;
							SELECT _statusmsg AS result, _statusno AS statuscode;

        END;
    END IF;

END
;;
delimiter ;

-- ----------------------------
-- Function structure for getvalue
-- ----------------------------
DROP FUNCTION IF EXISTS `getvalue`;
delimiter ;;
CREATE FUNCTION `getvalue`(`object` LONGTEXT, `field` VARCHAR(255))
 RETURNS longtext CHARSET utf8mb4 COLLATE utf8mb4_general_ci
  DETERMINISTIC
BEGIN
		DECLARE result LONGTEXT;
		SET result = JSON_UNQUOTE(JSON_EXTRACT(object, field));
		RETURN result;
	END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for get_apikey
-- ----------------------------
DROP PROCEDURE IF EXISTS `get_apikey`;
delimiter ;;
CREATE PROCEDURE `get_apikey`(IN JsonData LONGTEXT)
BEGIN
	DECLARE _statusmsg LONGTEXT DEFAULT 'Error Occured';
    DECLARE _statusno SMALLINT DEFAULT 0;

    DECLARE _email VARCHAR(255);
    DECLARE _password VARCHAR(255);
    DECLARE _api_key LONGTEXT;

    SET _email = getvalue(JsonData, '$.email');
    SET _password = getvalue(JsonData, '$.password');

    IF EXISTS (SELECT 1 FROM users WHERE email = _email AND users.`password` = _password) THEN

				SET _api_key = (SELECT apikey.api_key 
												FROM users 
												INNER JOIN apikey ON users.user_id = apikey.account_id 
												WHERE users.email = _email AND users.`password` = _password);

        IF _api_key IS NOT NULL THEN
						
             SELECT _api_key AS api_key;
            
        END IF;

		ELSE    
           SELECT _statusmsg AS result, _statusno AS statuscode;
    END IF;

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for notification_search
-- ----------------------------
DROP PROCEDURE IF EXISTS `notification_search`;
delimiter ;;
CREATE PROCEDURE `notification_search`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE Result_Status VARCHAR(100);
    DECLARE _SearchKey VARCHAR(255);
    
    SET _SearchKey = getvalue(JsonData,'$.SearchKey');
    SET Result_Status = CONCAT('No existing Record: ', _SearchKey);

    IF EXISTS (SELECT * FROM notification WHERE notification_id LIKE CONCAT('%', _SearchKey, '%') OR user_id LIKE CONCAT('%', _SearchKey, '%')) THEN
        BEGIN
            SELECT * FROM notification WHERE notification_id LIKE CONCAT('%', _SearchKey, '%') OR user_id LIKE CONCAT('%', _SearchKey, '%') LIMIT 1;
        END;
    ELSE
        BEGIN
            SELECT Result_Status;
        END;
    END IF;
    
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for notification_update
-- ----------------------------
DROP PROCEDURE IF EXISTS `notification_update`;
delimiter ;;
CREATE PROCEDURE `notification_update`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE _statusmsg LONGTEXT DEFAULT '" "';
    DECLARE _statusno SMALLINT DEFAULT 0;
    
    DECLARE _notification_id VARCHAR(20);
    DECLARE _user_id VARCHAR(50);
    DECLARE _notification_type VARCHAR(10);
    DECLARE _notification_date VARCHAR(20);
    DECLARE _is_read VARCHAR(20);

    SET _notification_id = getvalue(JsonData, '$.notification_id');
    SET _user_id = getvalue(JsonData, '$.user_id');
    SET _notification_type = getvalue(JsonData, '$.notification_type');
    SET _notification_date = getvalue(JsonData, '$.notification_date');
    SET _is_read = getvalue(JsonData, '$.is_read');
   
 
    IF EXISTS (SELECT * FROM notification WHERE notification_id = _notification_id) THEN
        BEGIN
            UPDATE notification 
            SET notification_id = _notification_id,
                user_id = _user_id,
                notification_type = _notification_type,
                notification_date = _notification_date,
                is_read = _is_read
            WHERE notification_id = _notification_id;

            SET _statusmsg = "RECORD UPDATED";
            SET _statusno = 1;
            SELECT _statusmsg AS result, _statusno AS statuscode;
        END;
    ELSE
        BEGIN
            IF _notification_id IS NOT NULL THEN
                INSERT INTO notification (
                    notification_id,
                    user_id,
                    notification_type,
                    notification_date,
                    is_read
                ) VALUES (
                    _notification_id,
                    _user_id,
                    _notification_type,
                    _notification_date,
                    _is_read
                );

                SET _statusmsg = "RECORD INSERTED";
                SET _statusno = 1;
                SELECT _statusmsg AS result, _statusno AS statuscode;
            ELSE    
                SELECT _statusmsg AS result, _statusno AS statuscode;
            END IF;
        END;
    END IF;    
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for notifucations_load
-- ----------------------------
DROP PROCEDURE IF EXISTS `notifucations_load`;
delimiter ;;
CREATE PROCEDURE `notifucations_load`()
BEGIN
	SELECT * FROM notification;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for position_load
-- ----------------------------
DROP PROCEDURE IF EXISTS `position_load`;
delimiter ;;
CREATE PROCEDURE `position_load`()
BEGIN
	SELECT * FROM positions;

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for position_update
-- ----------------------------
DROP PROCEDURE IF EXISTS `position_update`;
delimiter ;;
CREATE PROCEDURE `position_update`(IN JsonData LONGTEXT)
BEGIN

		DECLARE _statusmsg LONGTEXT DEFAULT 'ERROR OCCURED';
    DECLARE _statusno SMALLINT DEFAULT 0;
		
    DECLARE _position_id INT;
    DECLARE _position_name VARCHAR(255);
		
    SET _position_id = getvalue(JsonData, '$.position_id');
		SET _position_name = getvalue(JsonData, '$.position_name');
		
		
    IF EXISTS (SELECT * FROM positions WHERE position_id = _position_id) THEN
        BEGIN
            UPDATE positions 
            SET position_name = _position_name
            WHERE position_id = _position_id;
							
							SET _statusmsg = "RECORD UPDATED";
              SET _statusno = 1;
							SELECT _statusmsg AS result, _statusno AS statuscode;
        END;
    ELSE
        BEGIN
	
              INSERT INTO positions (position_name)
              VALUES (_position_name);

              
							SET _statusmsg = "RECORD INSERTED";
              SET _statusno = 1;
							SELECT _statusmsg AS result, _statusno AS statuscode;

        END;
    END IF;


END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for statedef_load
-- ----------------------------
DROP PROCEDURE IF EXISTS `statedef_load`;
delimiter ;;
CREATE PROCEDURE `statedef_load`()
BEGIN

	SELECT documenttypes.documenttype_name, state_def.*
	FROM state_def
	INNER JOIN documenttypes ON state_def.documenttype_id = documenttypes.documenttype_id;

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for statedef_load_perdoc
-- ----------------------------
DROP PROCEDURE IF EXISTS `statedef_load_perdoc`;
delimiter ;;
CREATE PROCEDURE `statedef_load_perdoc`(IN `JsonData` LONGTEXT)
BEGIN
	DECLARE _statusmsg VARCHAR(255) DEFAULT 'ERROR OCCURED';
  DECLARE _statusno SMALLINT DEFAULT 0;

	DECLARE _documenttype_id INT;
	DECLARE _state VARCHAR(100);
	
	SET _documenttype_id = getvalue(JsonData, '$.documenttype_id');
	
	IF EXISTS (SELECT * FROM documenttypes WHERE documenttype_id = _documenttype_id) THEN
	
			SELECT state, state_desc FROM state_def WHERE documenttype_id = _documenttype_id;
			
	ELSE

			SELECT _statusmsg AS result, _statusno AS statuscode;

	END IF;

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for statedef_search
-- ----------------------------
DROP PROCEDURE IF EXISTS `statedef_search`;
delimiter ;;
CREATE PROCEDURE `statedef_search`(IN `JsonData` LONGTEXT)
BEGIN
	
	SELECT * FROM state_def
	
	RIGHT JOIN documenttypes ON state_def.documenttype_id = documenttypes.documenttype_id
	
	WHERE state_def.documenttype_id = JsonData OR documenttypes.documenttype_name LIKE CONCAT('%',JsonData,'%');

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for statedef_update
-- ----------------------------
DROP PROCEDURE IF EXISTS `statedef_update`;
delimiter ;;
CREATE PROCEDURE `statedef_update`(IN `JsonData` LONGTEXT)
BEGIN
	
  DECLARE _statusmsg VARCHAR(255) DEFAULT 'ERROR OCCURED';
  DECLARE _statusno SMALLINT DEFAULT 0;

	DECLARE _documenttype_id INT;
	DECLARE _state VARCHAR(255);
	DECLARE _state_desc VARCHAR(255);
	
	SET _documenttype_id = getvalue(JsonData, '$.documenttype_id');
	SET _state = getvalue(JsonData, '$.state');
	SET _state_desc = getvalue(JsonData, '$.state_desc');
	
	IF EXISTS (SELECT * FROM state_def WHERE documenttype_id = _documenttype_id) THEN
	
			UPDATE state_def
					SET state = _state,
							state_desc = _state_desc,
							documenttype_id = _documenttype_id
					WHERE documenttype_id = _documenttype_id;
				
				 SET _statusmsg = "RECORD UPDATED";
         SET _statusno = 1;
         SELECT _statusmsg AS result, _statusno AS statuscode;
	ELSE
	
			INSERT INTO state_def (state, state_desc, documenttype_id)
						VALUES (_state, _state_desc, _documenttype_id);
					
					SET _statusmsg = "RECORD INSERTED";
          SET _statusno = 1;
          SELECT _statusmsg AS result, _statusno AS statuscode;
	END IF;

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for users_load
-- ----------------------------
DROP PROCEDURE IF EXISTS `users_load`;
delimiter ;;
CREATE PROCEDURE `users_load`(IN JsonData LONGTEXT)
BEGIN

DECLARE _statusmsg LONGTEXT DEFAULT 'ERROR OCCURED';
    DECLARE _statusno SMALLINT DEFAULT 0;
		
    DECLARE _password VARCHAR(255);
    DECLARE _email VARCHAR(255);


    SET _password = getvalue(JsonData, '$.password');
    SET _email = getvalue(JsonData, '$.email');

		
    IF EXISTS (SELECT * FROM users WHERE email = _email) THEN
        BEGIN
            SELECT * FROM users WHERE email = _email AND `password` = _password;
        END;
    ELSE
				SELECT _statusmsg AS result, _statusno AS statuscode;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for users_load_info
-- ----------------------------
DROP PROCEDURE IF EXISTS `users_load_info`;
delimiter ;;
CREATE PROCEDURE `users_load_info`()
BEGIN

	SELECT positions.position_name, documenttypes.documenttype_name, access_type, users.full_name, users.username 
	FROM users
	LEFT JOIN positions ON users.position_id = positions.position_id
	LEFT JOIN accesscontrol ON positions.position_id = accesscontrol.position_id
	LEFT JOIN documenttypes ON accesscontrol.documenttype_id = documenttypes.documenttype_id;

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for users_search
-- ----------------------------
DROP PROCEDURE IF EXISTS `users_search`;
delimiter ;;
CREATE PROCEDURE `users_search`(IN `JsonData` LONGTEXT)
BEGIN
	DECLARE Result_Status LONGTEXT;
	DECLARE _SearchKey VARCHAR(255);
    
    SET _SearchKey = getvalue(JsonData, '$.searchKey');
    
   SET Result_Status = CONCAT('No existing Record: ', _SearchKey);
	
	IF EXISTS(SELECT * FROM users WHERE user_id LIKE CONCAT('%', _SearchKey, '%') OR email = _SearchKey OR username LIKE CONCAT('%', _SearchKey, '%') OR `password` = _SearchKey) THEN
	
		SELECT * FROM users WHERE user_id LIKE CONCAT('%', _SearchKey, '%') OR email = _SearchKey OR username LIKE CONCAT('%', _SearchKey, '%') OR `password` = _SearchKey;
		
	ELSE 
		SET Result_Status = "No Match";
		SELECT Result_Status AS Result;
	END IF;

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for users_update
-- ----------------------------
DROP PROCEDURE IF EXISTS `users_update`;
delimiter ;;
CREATE PROCEDURE `users_update`(IN `JsonData` LONGTEXT)
BEGIN
    DECLARE _statusmsg LONGTEXT DEFAULT 'ERROR OCCURED';
    DECLARE _statusno SMALLINT DEFAULT 0;
		
    DECLARE _user_id INT;
    DECLARE _username VARCHAR(255);
    DECLARE _password VARCHAR(255);
    DECLARE _full_name VARCHAR(255);
    DECLARE _email VARCHAR(255);
    DECLARE _position_id INT;
		DECLARE _department_id INT;
		DECLARE _user_type VARCHAR(100);

    SET _user_id = getvalue(JsonData, '$.user_id');
    SET _username = getvalue(JsonData, '$.username');
    SET _password = getvalue(JsonData, '$.password');
    SET _full_name = getvalue(JsonData, '$.full_name');
    SET _email = getvalue(JsonData, '$.email');
    SET _position_id = getvalue(JsonData, '$.position_id');
		SET _department_id = getvalue(JsonData, '$.department_id');
		SET _user_type = UPPER(getvalue(JsonData, '$.user_type')) ;
		
		
    IF EXISTS (SELECT * FROM users WHERE email = _email) THEN
        BEGIN
            UPDATE users 
            SET username = _username,
                `password` = _password,
                full_name = _full_name,
                email = _email,
                position_id = _position_id,
								department_id = _department_id,
								user_type = _user_type
            WHERE email = _email;
							
							SET _statusmsg = "RECORD UPDATED";
              SET _statusno = 1;
							SELECT _statusmsg AS result, _statusno AS statuscode;
        END;
    ELSE
        BEGIN
	
              INSERT INTO users (username, `password`, full_name, email, position_id, department_id, user_type)
              VALUES (_username, _password, _full_name, _email, _position_id, _department_id, _user_type);

              
							SET _statusmsg = "RECORD INSERTED";
              SET _statusno = 1;
							SELECT _statusmsg AS result, _statusno AS statuscode;

        END;
    END IF;
		
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table documenthistory
-- ----------------------------
DROP TRIGGER IF EXISTS `modifiedDate`;
delimiter ;;
CREATE TRIGGER `modifiedDate` AFTER INSERT ON `documenthistory` FOR EACH ROW BEGIN
IF EXISTS (SELECT * FROM documents WHERE user_id = NEW.actor) THEN

 UPDATE documents
 SET last_modified_date = NEW.action_date
 WHERE document_id = NEW.document_id;
 
END IF;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
