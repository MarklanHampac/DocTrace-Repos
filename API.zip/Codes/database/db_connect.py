from flask_mysqldb import MySQL
from flask import Flask


def create_app():
    app = Flask(__name__)
    app.config["MYSQL_HOST"] = "localhost"
    app.config["MYSQL_PORT"] = 3307
    app.config["MYSQL_USER"] = "root"
    app.config["MYSQL_PASSWORD"] = "maklizy1245"
    app.config["MYSQL_DB"] = "dts_db_2"
    app.config["MYSQL_CURSORCLASS"] = "DictCursor"

    return app


def init_mysql(app):
    mysql = MySQL(app)
    return mysql
