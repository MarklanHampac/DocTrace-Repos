from database.db_connect import create_app, init_mysql
from controller.controller import controller

app = create_app()
mysql = init_mysql(app)

# Register blueprints
app.register_blueprint(controller, url_prefix="/Module")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
