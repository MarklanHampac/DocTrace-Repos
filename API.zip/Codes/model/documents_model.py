from database.db_connect import create_app, init_mysql
from flask import Flask, jsonify, request
import json
import JWT_Token
import pysftp
from flask import request, jsonify
import json
import FTP_connection as FTP_Conn
import os

mysql = init_mysql(create_app())


def load_document_per_position():
    try:
        data = request.get_json()
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute(f"CALL documents_load_perposition('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


def load_document():
    try:
        data = request.get_json()
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute(f"CALL documents_load('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


def update_document_status():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call documents_update_state('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def update_document_docstatus():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call documents_update_docstatus('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def create_document():
    try:
        # Get the file content from the request
        file = request.files.get("file")

        # Other data from the request
        data = request.form.to_dict()
        fdata = data.get("metadata")
        fdata1 = json.loads(fdata)
        print("Received metadata:", data)
        title = fdata1.get("title")
        user_id = fdata1.get("user_id")
        description = fdata1.get("description")
        author = fdata1.get("author")
        status = fdata1.get("status")
        documenttype_id = fdata1.get("documenttype_id")
        department_id = fdata1.get("department_id")

        if file:
            # Save the file to a temporary location
            filename = file.filename
            temp_file_path = os.path.join("/tmp", filename)
            file.save(temp_file_path)

            # Upload the file to the SFTP server
            cnopts = pysftp.CnOpts()
            cnopts.hostkeys = None

            with pysftp.Connection(
                host=FTP_Conn.sftp_host,
                username=FTP_Conn.sftp_user,
                password=FTP_Conn.sftp_pass,
                cnopts=cnopts,
            ) as sftp:
                # Upload the file
                newfilename = FTP_Conn.upload_file(
                    sftp,
                    temp_file_path,
                    "/",  # remote folder
                    filename,
                )

            # Remove the temporary file
            os.remove(temp_file_path)

            # Prepare the data to be saved in the database
            new_data = {
                "title": title,
                "user_id": user_id,
                "description": description,
                "author": author,
                "status": status,
                "documenttype_id": documenttype_id,
                "department_id": department_id,
                "file_path": "/" + newfilename,
            }

            print(new_data)
            cur = mysql.connection.cursor()
            cur.execute(f"call documents_update('{json.dumps(new_data)}')")
            result = cur.fetchall()
            cur.close()
            mysql.connection.commit()
            return jsonify(result)
        else:
            return jsonify({"error": "No file provided"}), 400

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def download_document():

    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None
    with pysftp.Connection(
        host=FTP_Conn.sftp_host,
        username=FTP_Conn.sftp_user,
        password=FTP_Conn.sftp_pass,
        cnopts=cnopts,
    ) as sftp:
        # Download a file - Problem(how to get sftp filename and path)
        FTP_Conn.download_file(
            sftp, "remote_file.txt", "/path/to/your/local/downloaded_file.txt"
        )
