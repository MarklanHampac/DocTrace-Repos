from database.db_connect import create_app, init_mysql
from flask import Flask, jsonify, request
import json
import JWT_Token
import pysftp
from flask import request, jsonify
import json
import FTP_connection as FTP_Conn
import os

mysql = init_mysql(create_app())


# def login_user():
#     # Retrieve JSON data from the request
#     data = request.get_json()

#     # Extract username, password, and email from the JSON data
#     username = data.get("username")
#     password = data.get("password")
#     email = data.get("email")

#     if not username or not password or not email:
#         return jsonify({"error": "Username, password, and email are required"}), 400

#     try:
#         # Execute the stored procedure to get API key
#         cur = mysql.connection.cursor()
#         cur.execute("CALL GetApiKey(%s, %s, %s)", (username, password, email))
#         result = cur.fetchone()
#         cur.close()

#         if result:
#             if "api_key" in result:  # Check if API key is retrieved
#                 db_api_key = result["api_key"]

#                 # Generate JWT token using user_info
#                 user_info = {
#                     "username": data["username"],
#                     "password": data["password"],
#                     "email": data["email"],
#                 }
#                 jwt_api_key = JWT_Token.generateJWToken(user_info)

#                 # Compare the API key from database with JWT generated API key
#                 if jwt_api_key == db_api_key:
#                     verification_message = "Key verified"
#                 else:
#                     verification_message = "Key verification failed"

#                 # Create response dictionary
#                 response_data = {
#                     "Result": "Login successful",
#                     "Verification": verification_message,
#                     "Database_API_Key": db_api_key,
#                     "Generated_API_Key": jwt_api_key,
#                 }

#                 # Attach API key to the response
#                 response_data["APIKey"] = db_api_key

#                 # Create a JSON response
#                 response = jsonify(response_data)
#                 return response
#             else:
#                 # API key retrieval failed
#                 return jsonify({"error": result["error"]}), 401
#         else:
#             return jsonify({"error": "Login failed"}), 401
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500


def register():
    try:
        if request.method == "POST":

            data = request.get_json()
            print(data)
            cur = mysql.connection.cursor()
            cur.execute(f"call users_update('{json.dumps(data)}')")
            result = cur.fetchall()
            cur.close()
            mysql.connection.commit()

            # Generating Token============================
            user_info = {
                "username": data["username"],
                "password": data["password"],
                "email": data["email"],
            }
            token = JWT_Token.generateJWToken(user_info)
            # =============================================

            if result[0]["statuscode"] == 1:
                # Searching for User
                searchkey = {"SearchKey": data["email"]}
                cur = mysql.connection.cursor()
                cur.execute(f"call users_search('{json.dumps(searchkey)}')")
                user_id = cur.fetchone()
                cur.close()
                mysql.connection.commit()

                # Insertign JWT token to DB
                if user_id:
                    apiInfo = {"account_id": user_id["user_id"], "api_key": token}
                    JWT_Token.insertJWToken(apiInfo)
                else:
                    return jsonify({"error": user_id}), 400

            response = jsonify({"result": result})
            return response
        return jsonify({"error": "Invalid request method"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def createDoc():
    try:
        data = request.get_json()

        # get the file and the file path from front end and send to sftp server=============================
        # Disable hoskeys(Not Final/Might change)
        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None

        file_path = data["file_path"]
        filename = os.path.basename(file_path)
        print(filename)

        with pysftp.Connection(
            host=FTP_Conn.sftp_host,
            username=FTP_Conn.sftp_user,
            password=FTP_Conn.sftp_pass,
            cnopts=cnopts,
        ) as sftp:
            # Upload a file
            newfilename = FTP_Conn.upload_file(
                sftp,
                file_path,
                "/",  # remote folder
                filename,
            )
        # ====================================================================================================
        print(newfilename)
        # Problem(How to get "filename" from sftp server)
        # new_data = {
        #     "title": data["title"],
        #     "user_id": data["user_id"],
        #     "description": data["description"],
        #     "author": data["author"],
        #     "status": data["status"],
        #     "documenttype_id": data["documenttype_id"],
        #     "department_id": data["department_id"],
        #     "file_path": "/" + newfilename,  # "filename" must be from sftp server
        # }

        data["file_path"] = "/" + newfilename

        print(data)
        cur = mysql.connection.cursor()
        cur.execute(f"call documents_update('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def downLoadDoc():

    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None
    with pysftp.Connection(
        host=FTP_Conn.sftp_host,
        username=FTP_Conn.sftp_user,
        password=FTP_Conn.sftp_pass,
        cnopts=cnopts,
    ) as sftp:
        # Download a file - Problem(how to get sftp filename and path)
        FTP_Conn.download_file(
            sftp, "remote_file.txt", "/path/to/your/local/downloaded_file.txt"
        )


def loadDocPerPosition():
    try:
        data = request.get_json()
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute(f"CALL documents_load_perposition('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


def updateDocStatus():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call documents_update_state('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def load_accesscontrol():
    try:
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute("CALL accesscontrol_load()")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


def load_user_info():
    try:
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute("CALL users_load_info()")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code
