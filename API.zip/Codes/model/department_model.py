from database.db_connect import create_app, init_mysql
from flask import Flask, jsonify, request
import json
import JWT_Token
import pysftp
from flask import request, jsonify
import json
import FTP_connection as FTP_Conn
import os

mysql = init_mysql(create_app())


def update_department():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call departments_update('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def search_department():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call departments_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    return response


def load_department():
    try:
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute("CALL departments_load()")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code
