import pysftp
import re

sftp_host = "127.0.0.1"
sftp_user = "maklizy_SFTP"
sftp_pass = "maklizy"


def upload_file(sftp, local_file_path, remote_folder, remote_file_name):
    with sftp.cd(remote_folder):
        # Upload the file
        sftp.put(local_file_path, remote_file_name)

        # Get the list of files in the remote directory
        remote_files = sftp.listdir()

        # Find the new filename
        new_filename = None
        for file in remote_files:
            if file.startswith(remote_file_name):
                new_filename = file  # Set the new filename
                break

        # Extract timestamp if appended
        timestamp = None
        if new_filename:
            match = re.search(r"\d{2}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}", new_filename)
            if match:
                timestamp = match.group()

        return f"{new_filename}_{timestamp}"


def download_file(sftp, remote_file_name, local_file_path):
    sftp.get(remote_file_name, local_file_path)
