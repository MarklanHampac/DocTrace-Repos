from database.db_connect import create_app, init_mysql
import jwt
import json

app = create_app()
mysql = init_mysql(app)
key = app.config["SECRET_KEY"] = "Marklan"


def generateJWToken(user_info):
    # Create a JWT token
    token = jwt.encode({"user_info": user_info}, key, algorithm="HS256")

    return token


def insertJWToken(apiInfo):
    cur = mysql.connection.cursor()
    cur.execute(f"call apikey_update('{json.dumps(apiInfo)}')")
    cur.close()
    mysql.connection.commit()
