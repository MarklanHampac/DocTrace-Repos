import smtplib
from email.mime.text import MIMEText
from pyotp import TOTP


# Function to send OTP via email
def send_otp_email(email, otp):
    sender_email = "mhampac07@gmail.com"
    sender_password = "lkax crpj sztx eemv"

    msg = MIMEText(f"Your OTP is: {otp}")
    msg["Subject"] = "OTP Verification"
    msg["From"] = sender_email
    msg["To"] = email

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, email, msg.as_string())
        server.quit()
        print("OTP sent successfully!")
    except Exception as e:
        print("Error sending OTP:", e)
