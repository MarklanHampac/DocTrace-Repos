from flask import Blueprint, jsonify, request, session, redirect, url_for
from functools import wraps
import model.user_model as user_model
import model.access_control_model as access_control_model
import model.document_type_model as document_type_model
import model.department_model as department_model
import model.position_model as position_model
import model.state_def_model as state_def_model
import model.documents_model as documents_model

controller = Blueprint("controller", __name__)

# =========================user=======================#


@controller.route("/register-user", methods=["POST"])
def user_register():
    response = user_model.register_user()
    return response


@controller.route("/login-user", methods=["POST"])
def user_login():
    response = user_model.login_user()
    return response


@controller.route("/verify-otp", methods=["POST"])
def otp_verification():
    response = user_model.verify_otp()
    return response


@controller.route("/logout-user", methods=["POST"])
def user_logout():
    response = user_model.user_logout()
    return response


@controller.route("/load-user-info", methods=["POST"])
def load_user_info():
    response = user_model.load_user_info()
    return response


@controller.route("/load-user", methods=["POST"])
def load_user():
    response = user_model.load_users()
    return response


# =========================user=======================#

# =========================documents=======================#


@controller.route("/create-document", methods=["POST"])
def create_doc():
    response = documents_model.create_document()
    return response


@controller.route("/download-document", methods=["POST"])
def download_doc():
    response = documents_model.download_document()
    return response


@controller.route("/update-document-status", methods=["POST"])
def update_doc_status():
    response = documents_model.update_document_status()
    return response


@controller.route("/update-document-docstatus", methods=["POST"])
def update_docstatus():
    response = documents_model.update_document_docstatus()
    return response


@controller.route("/load-document-per-position", methods=["POST"])
def load_doc_perposition():
    response = documents_model.load_document_per_position()
    return response


@controller.route("/load-document", methods=["POST"])
def load_doc():
    response = documents_model.load_document()
    return response


# =========================documents=======================#

# =========================access-control=======================#


@controller.route("/update-access-control", methods=["POST"])
def update_access_control():
    response = access_control_model.update_accesscontrol()
    return response


@controller.route("/search-access_control", methods=["POST"])
def search_access_control():
    response = access_control_model.search_accesscontrol()
    return response


@controller.route("/load-access-control", methods=["POST"])
def load_access_control():
    response = access_control_model.load_accesscontrol()
    return response


# =========================access-control=======================#

# =========================document-type=======================#


@controller.route("/load-document-type-status", methods=["POST"])
def load_document_type_status():
    response = document_type_model.load_documenttype_status()
    return response


@controller.route("/load-document-type", methods=["POST"])
def load_document_type():
    response = document_type_model.load_documenttype()
    return response


@controller.route("/update-document-type", methods=["POST"])
def update_document_type():
    response = document_type_model.update_documenttype()
    return response


# =========================document-type=======================#

# =========================position=======================#


@controller.route("/load-position", methods=["POST"])
def load_position():
    response = position_model.load_position()
    return response


@controller.route("/update-position", methods=["POST"])
def update_position():
    response = position_model.update_position()
    return response


# =========================position=======================#

# =========================state-definition=======================#


@controller.route("/load-state-definition", methods=["POST"])
def load_state_def():
    response = state_def_model.statedef_load_users()
    return response


@controller.route("/update-state-definition", methods=["POST"])
def update_state_def():
    response = state_def_model.statedef_update_users()
    return response


@controller.route("/load-state-definition-perdoc", methods=["POST"])
def load_state_def_perdoc():
    response = state_def_model.statedef_load_perdoc_users()
    return response


# =========================state-definition=======================#

# =========================department=======================#


@controller.route("/load-department", methods=["POST"])
def load_department():
    response = department_model.load_department()
    return response


@controller.route("/update-department", methods=["POST"])
def update_department():
    response = department_model.update_department()
    return response


# =========================department=======================#
