from flask_mysqldb import MySQL
from flask import Flask
from flask import Flask, session
from flask_session import Session


def create_app():

    app = Flask(__name__)
    # Set the secret key to a sufficiently random value
    app.secret_key = "supersecretkey"

    # Configure session to use filesystem (server-side session)
    app.config["SESSION_TYPE"] = "filesystem"
    app.config["SESSION_PERMANENT"] = False
    app.config["SESSION_USE_SIGNER"] = True
    app.config["SESSION_KEY_PREFIX"] = "myapp_"

    # Initialize the session with the app
    Session(app)

    app.config["MYSQL_HOST"] = "localhost"
    app.config["MYSQL_PORT"] = 3307
    app.config["MYSQL_USER"] = "root"
    app.config["MYSQL_PASSWORD"] = "maklizy1245"
    app.config["MYSQL_DB"] = "dts_db_2"
    app.config["MYSQL_CURSORCLASS"] = "DictCursor"

    return app


def init_mysql(app):
    mysql = MySQL(app)
    return mysql
