from pyotp import random_base32
from database.db_connect import create_app, init_mysql
from flask import Flask, jsonify, request, session
import json
import JWT_Token
import pysftp
from flask import request, jsonify
import json
import FTP_connection as FTP_Conn
import os
import uuid
import OTP as genOTP

mysql = init_mysql(create_app())


# ===========================start of user SP====================================== #
def login_user():
    # Retrieve JSON data from the request
    data = request.get_json()

    # Extract email and password from the JSON data
    if "email" not in data or "password" not in data:
        return jsonify({"error": "Password and email are required"}), 400

    try:
        # Execute the stored procedure to get API key
        cur = mysql.connection.cursor()
        cur.execute(f"CALL get_apikey('{json.dumps(data)}')")
        result = cur.fetchone()
        cur.close()

        if result:
            verification_message_success = "Key verified"
            verification_message_failed = "Key verification failed"

            if "api_key" in result:  # Check if API key is retrieved
                db_api_key = result["api_key"]

                # Generate JWT token using user_info
                user_info = {
                    "password": data["password"],
                    "email": data["email"],
                }
                jwt_api_key = JWT_Token.generateJWToken(user_info)

                # Compare the API key from database with JWT generated API key
                if jwt_api_key == db_api_key:
                    # Check for existing active session
                    cur = mysql.connection.cursor()
                    cur.execute(f"Call user_check_loginsession('{data['email']}')")
                    session_result = cur.fetchone()
                    cur.close()

                    if session_result["session_token"] != "0":
                        return (
                            jsonify(
                                {"error": "User already logged in from another device"}
                            ),
                            403,
                        )

                    # Generate OTP
                    otp_secret = random_base32()
                    otp = genOTP.TOTP(otp_secret).now()

                    # Send OTP via email
                    genOTP.send_otp_email(data["email"], otp)
                    otp_verification = {
                        "otp": otp,
                        "email": data["email"],
                        "password": data["password"],
                    }

                    cur = mysql.connection.cursor()
                    cur.execute(
                        f"Call user_update_otp('{json.dumps(otp_verification)}')"
                    )
                    cur.close()
                    mysql.connection.commit()

                    # Generate a new session token
                    session_token = str(uuid.uuid4())
                    print(session_token)
                    # Store user information and session token in session
                    session["user_email"] = data["email"]
                    session["session_token"] = session_token
                    print(session["user_email"])
                    session_info = {
                        "email": session["user_email"],
                        "session_token": session["session_token"],
                    }

                    # Update the user's active session token in the database
                    cur = mysql.connection.cursor()
                    cur.execute(
                        f"Call user_update_sessiontoken('{json.dumps(session_info)}')"
                    )
                    cur.close()
                    mysql.connection.commit()

                    # Create response dictionary
                    response_data = {
                        "Result": "OTP sent successfully. Please verify the OTP.",
                        "Verification": "OTP sent",
                        "Database_API_Key": db_api_key,
                        "Generated_API_Key": jwt_api_key,
                    }

                    return jsonify(response_data), 200

                else:
                    # API key retrieval failed
                    return (
                        jsonify(
                            {
                                "error": "Login failed",
                                "Verification": verification_message_failed,
                            }
                        ),
                        401,
                    )
            else:
                return jsonify({"error": jsonify(result)}), 401
        else:
            return jsonify({"error": jsonify(result)}), 401
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def verify_otp():
    data = request.get_json()

    if "email" not in data or "otp" not in data:
        return jsonify({"error": "Email and OTP are required"}), 400

    try:
        verify_otp = {
            "action": "Get",
            "email": data["email"],
        }

        cur = mysql.connection.cursor()
        cur.execute(f"Call users_verify_otp('{json.dumps(verify_otp)}')")
        result = cur.fetchone()
        cur.close()

        if result and result["otp"] == data["otp"]:

            verify_otp1 = {
                "action": "Reset",
                "email": data["email"],
            }

            cur = mysql.connection.cursor()
            cur.execute(f"Call users_verify_otp('{json.dumps(verify_otp1)}')")
            cur.close()
            mysql.connection.commit()

            return (
                jsonify(
                    {
                        "message": "OTP verification successful",
                        "Result": "Login successful",
                    }
                ),
                200,
            )
        else:
            return jsonify({"error": "Invalid OTP"}), 401
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def user_logout():
    if "user_email" in session:
        email = session["user_email"]

        update_session = {
            "email": email,
            "session_token": 0,
        }

        # Clear the session token in the database
        cur = mysql.connection.cursor()
        cur.execute(f"Call user_update_sessiontoken('{json.dumps(update_session)}')")
        cur.close()
        mysql.connection.commit()

        # Clear the session
        session.pop("user_email", None)
        session.pop("session_token", None)

        return jsonify({"message": "Logged out"}), 200
    else:
        return jsonify({"error": "No user logged in"}), 400


def register_user():
    try:
        if request.method == "POST":

            data = request.get_json()
            print(data)
            cur = mysql.connection.cursor()
            cur.execute(f"call users_update('{json.dumps(data)}')")
            result = cur.fetchall()
            cur.close()
            mysql.connection.commit()

            # Generating Token============================
            user_info = {
                "password": data["password"],
                "email": data["email"],
            }
            token = JWT_Token.generateJWToken(user_info)
            # =============================================

            if result[0]["statuscode"] == 1:
                # Searching for User
                searchkey = {"searchKey": data["email"]}
                cur = mysql.connection.cursor()
                cur.execute(f"call users_search('{json.dumps(searchkey)}')")
                user_id = cur.fetchone()
                cur.close()
                mysql.connection.commit()

                # Insertign JWT token to DB
                if user_id:
                    apiInfo = {"account_id": user_id["user_id"], "api_key": token}
                    JWT_Token.insertJWToken(apiInfo)
                else:
                    return jsonify({"error": user_id}), 400

            response = jsonify({"result": result})
            return response
        return jsonify({"error": "Invalid request method"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def update_users():
    try:
        data = request.get_json()

        cur = mysql.connection.cursor()
        cur.execute(f"call users_update('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()
        mysql.connection.commit()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def search_users():
    data = request.get_json()
    data_string = json.dumps(data)

    cur = mysql.connection.cursor()
    cur.execute(f"call users_search('{data_string}')")
    result = cur.fetchall()
    cur.close()

    response = jsonify(result)
    response.headers["Custom-Header"]
    return response


def load_users():
    try:
        data = request.get_json()
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute(f"CALL users_load('{json.dumps(data)}')")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


def load_user_info():
    try:
        # Execute the stored procedure to load state definitions
        cur = mysql.connection.cursor()
        cur.execute("CALL users_load_info()")
        result = cur.fetchall()
        cur.close()

        # Assuming result is a list of tuples representing state definitions
        # You may need to adjust this based on the actual result format
        response_body = jsonify(result)
        status_code = 200  # OK status code

        # Optionally, you can add custom headers if needed
        headers = {"Custom-Header": "Value"}

        # Return the valid response tuple
        return response_body, status_code, headers

    except Exception as e:
        # If an exception occurs, return an error response
        error_message = str(e)
        response_body = jsonify({"error": error_message})
        status_code = 500  # Internal Server Error status code
        return response_body, status_code


######### END OF USER SP ###########
