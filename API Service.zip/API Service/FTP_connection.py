import pysftp
import re
from pathlib import Path
import shutil
import tempfile
import os
from urllib.parse import urlparse, unquote

sftp_host = "127.0.0.1"
sftp_user = "maklizy_SFTP"
sftp_pass = "maklizy"


def upload_file(sftp, local_file_path, remote_folder, remote_file_name):
    with sftp.cd(remote_folder):
        # Upload the file
        sftp.put(local_file_path, remote_file_name)

        # Return the uploaded filename
        return remote_file_name


def download_file_to_temp(sftp, remote_file_path):
    try:
        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            sftp.get(remote_file_path, temp_file.name)
            print("File downloaded successfully from SFTP server to temporary file")
            return temp_file.name
    except Exception as e:
        print("Error downloading file from SFTP server:", str(e))
        raise


BUFFER_SIZE = 8192  # Adjust the buffer size as needed


def write_file_data_to_uri(uri, temp_file_path):
    try:
        # Parse the Uri
        parsed_uri = urlparse(uri)

        # Handle the "content://" scheme
        if parsed_uri.scheme == "content":
            # Extract the file path from the Uri path
            uri_path = unquote(parsed_uri.path)
            file_path = uri_path.split("/")[-1]

            # Construct the full file path on the server
            server_file_path = Path("/path/to/download/directory") / file_path

            # Create the directory if it doesn't exist
            server_file_path.parent.mkdir(parents=True, exist_ok=True)

            # Write the file data to the specified location
            with server_file_path.open("wb") as output_file:
                with open(temp_file_path, "rb") as input_file:
                    while True:
                        data = input_file.read(BUFFER_SIZE)
                        if not data:
                            break
                        output_file.write(data)
                output_file.flush()  # Flush the output stream

            print("File data written successfully to the specified Uri")
        else:
            print(f"Unsupported Uri scheme: {parsed_uri.scheme}")

    except Exception as e:
        print("Error writing file data to Uri:", str(e))
        raise
    finally:
        # Clean up the temporary file
        Path(temp_file_path).unlink()
